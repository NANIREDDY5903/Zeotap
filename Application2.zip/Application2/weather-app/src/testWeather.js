const https = require('https');

const apiKey = '48c8d32c4b55d019e46c2edf601bf9d6'; // Your API key
const city = 'Mumbai,in'; // City and country code

const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`;

https.get(url, (resp) => {
    let data = '';

    // A chunk of data has been received.
    resp.on('data', (chunk) => {
        data += chunk;
    });

    // The whole response has been received.
    resp.on('end', () => {
        const weatherData = JSON.parse(data);
        
        // Convert temperature from Kelvin to Celsius
        const tempCelsius = (weatherData.main.temp - 273.15).toFixed(2);
        const feelsLikeCelsius = (weatherData.main.feels_like - 273.15).toFixed(2);
        
        console.log(`Weather in ${city}:`);
        console.log(`Temperature: ${tempCelsius}°C`);
        console.log(`Feels Like: ${feelsLikeCelsius}°C`);
        console.log(`Main Condition: ${weatherData.weather[0].main}`);
    });

}).on("error", (err) => {
    console.log("Error: " + err.message);
});
