const { fetchWeatherData, kelvinToCelsius } = require('./weather');

const thresholdTemp = 35;

async function checkWeatherAlerts(city) {
    const data = await fetchWeatherData(city);
    if (data) {
        const tempCelsius = kelvinToCelsius(data.main.temp);
        if (tempCelsius > thresholdTemp) {
            console.log(`ALERT: Temperature in ${city} exceeds ${thresholdTemp}°C! Current temperature: ${tempCelsius}°C`);
        }
    }
}

module.exports = { checkWeatherAlerts };
