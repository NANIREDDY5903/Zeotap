const { fetchWeatherData, kelvinToCelsius } = require('./weather');

const cities = ['Delhi', 'Mumbai', 'Chennai', 'Bangalore', 'Kolkata', 'Hyderabad'];

async function processWeatherData() {
    for (const city of cities) {
        const data = await fetchWeatherData(city);
        if (data) {
            const tempCelsius = kelvinToCelsius(data.main.temp);
            console.log(`Weather in ${city}:`);
            console.log(`Temperature: ${tempCelsius}°C`);
            console.log(`Main Condition: ${data.weather[0].main}`);
            console.log('--------------------------------');
        }
    }
}

setInterval(processWeatherData, 5 * 60 * 1000);  // 5 minutes
