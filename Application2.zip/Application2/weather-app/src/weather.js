require('dotenv').config();
const axios = require('axios');

async function fetchWeatherData(city) {
    const apiKey = process.env.OPENWEATHERMAP_API_KEY;
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`;
    
    try {
        const response = await axios.get(url);
        return response.data;
    } catch (error) {
        console.error(`Error fetching weather data for ${city}:`, error);
        return null;
    }
}

function kelvinToCelsius(kelvin) {
    return (kelvin - 273.15).toFixed(2);
}

module.exports = { fetchWeatherData, kelvinToCelsius };
